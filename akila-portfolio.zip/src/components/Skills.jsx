import { useEffect, useRef } from 'react'
import { gsap } from '../utils/gsap'
import { useReducedMotion } from '../hooks/useReducedMotion'
import { skills } from '../data/portfolio'
import styles from './Skills.module.css'

// ── Tree layout constants ──────────────────────────────────
const ROOT        = { label: 'AKILA R.', sub: 'Full-Stack Frontend + AI' }
const NODE_W      = 148
const NODE_H      = 44
const ROOT_W      = 200
const ROOT_H      = 54
const COL_GAP     = 52   // horizontal gap between root and categories
const CAT_GAP     = 18   // vertical gap between category nodes
const ITEM_GAP    = 10   // vertical gap between skill items

// Pre-compute layout
function buildLayout() {
  const categories = skills  // 6 categories

  // Total height needed for all category nodes
  const catBlockH = categories.reduce((acc, cat) => {
    const itemsH = cat.items.length * (NODE_H + ITEM_GAP) - ITEM_GAP
    return acc + Math.max(NODE_H, itemsH) + CAT_GAP
  }, -CAT_GAP)

  const totalH    = Math.max(ROOT_H, catBlockH) + 80
  const rootX     = 40
  const rootY     = totalH / 2 - ROOT_H / 2
  const catX      = rootX + ROOT_W + COL_GAP
  const itemX     = catX + NODE_W + COL_GAP

  let catCursor   = (totalH - catBlockH) / 2
  const catNodes  = []
  const itemNodes = []
  const lines     = []   // { x1,y1,x2,y2, type: 'root-cat'|'cat-item' }

  categories.forEach((cat) => {
    const itemsH   = cat.items.length * (NODE_H + ITEM_GAP) - ITEM_GAP
    const blockH   = Math.max(NODE_H, itemsH)
    const catY     = catCursor + blockH / 2 - NODE_H / 2

    catNodes.push({ label: cat.category, x: catX, y: catY, w: NODE_W, h: NODE_H })

    // Root → Category elbow
    const rootMidY = rootY + ROOT_H / 2
    const catMidY  = catY + NODE_H / 2
    lines.push({
      type: 'root-cat',
      x1: rootX + ROOT_W, y1: rootMidY,
      x2: catX,           y2: catMidY,
    })

    // Category → each item
    cat.items.forEach((item, j) => {
      const itemY = catCursor + j * (NODE_H + ITEM_GAP)
      itemNodes.push({ label: item, x: itemX, y: itemY, w: NODE_W, h: NODE_H, catIdx: catNodes.length - 1 })

      const itemMidY = itemY + NODE_H / 2
      lines.push({
        type: 'cat-item',
        x1: catX + NODE_W, y1: catY + NODE_H / 2,
        x2: itemX,         y2: itemMidY,
        catIdx: catNodes.length - 1,
      })
    })

    catCursor += blockH + CAT_GAP
  })

  const svgW = itemX + NODE_W + 40
  const svgH = totalH

  return { rootX, rootY, catNodes, itemNodes, lines, svgW, svgH }
}

const LAYOUT = buildLayout()

export default function Skills() {
  const wrapRef   = useRef(null)
  const svgRef    = useRef(null)
  const reducedMotion = useReducedMotion()

  useEffect(() => {
    if (reducedMotion) return

    const svg      = svgRef.current
    const catLines = svg.querySelectorAll(`.${styles.lineRootCat}`)
    const itemLines = svg.querySelectorAll(`.${styles.lineCatItem}`)
    const catBoxes  = svg.querySelectorAll(`.${styles.catNode}`)
    const itemBoxes = svg.querySelectorAll(`.${styles.itemNode}`)
    const rootBox   = svg.querySelector(`.${styles.rootNode}`)

    // Set initial hidden states
    gsap.set([catLines, itemLines], { strokeDashoffset: 200, opacity: 0 })
    gsap.set([catBoxes, itemBoxes, rootBox], { scale: 0.8, opacity: 0, transformOrigin: 'center center' })

    const ctx = gsap.context(() => {
      const tl = gsap.timeline({
        scrollTrigger: {
          trigger: wrapRef.current,
          start: 'top 72%',
          once: true,
        }
      })

      // Root node
      tl.to(rootBox, { scale: 1, opacity: 1, duration: 0.4, ease: 'back.out(1.4)' })

      // Root → cat lines + cat nodes together
      tl.to(catLines, {
        strokeDashoffset: 0, opacity: 1,
        duration: 0.7, stagger: 0.07, ease: 'power2.out',
      }, '-=0.1')
      tl.to(catBoxes, {
        scale: 1, opacity: 1,
        duration: 0.35, stagger: 0.07, ease: 'back.out(1.4)',
      }, '<+=0.25')

      // Cat → item lines + item nodes
      tl.to(itemLines, {
        strokeDashoffset: 0, opacity: 1,
        duration: 0.5, stagger: 0.025, ease: 'power2.out',
      }, '-=0.2')
      tl.to(itemBoxes, {
        scale: 1, opacity: 1,
        duration: 0.3, stagger: 0.02, ease: 'back.out(1.2)',
      }, '<+=0.15')

    }, wrapRef)

    return () => ctx.revert()
  }, [reducedMotion])

  const { rootX, rootY, catNodes, itemNodes, lines, svgW, svgH } = LAYOUT

  // Split lines by type
  const rootCatLines = lines.filter(l => l.type === 'root-cat')
  const catItemLines = lines.filter(l => l.type === 'cat-item')

  return (
    <div ref={wrapRef} className={styles.wrap}>
      <div className={styles.scrollBox}>
        <svg
          ref={svgRef}
          viewBox={`0 0 ${svgW} ${svgH}`}
          className={styles.svg}
          style={{ width: svgW, minWidth: svgW, height: svgH }}
          aria-label="Skills tree"
        >
          {/* ── Root → Category lines ── */}
          {rootCatLines.map((l, i) => (
            <path
              key={`rc-${i}`}
              className={styles.lineRootCat}
              d={elbowPath(l)}
              strokeDasharray="200"
              strokeDashoffset="200"
            />
          ))}

          {/* ── Category → Item lines ── */}
          {catItemLines.map((l, i) => (
            <path
              key={`ci-${i}`}
              className={styles.lineCatItem}
              d={elbowPath(l)}
              strokeDasharray="200"
              strokeDashoffset="200"
            />
          ))}

          {/* ── Root node ── */}
          <g className={styles.rootNode}>
            <rect x={rootX} y={rootY} width={ROOT_W} height={ROOT_H} rx="4" className={styles.rootRect} />
            <text x={rootX + ROOT_W / 2} y={rootY + 20} className={styles.rootLabel}>{ROOT.label}</text>
            <text x={rootX + ROOT_W / 2} y={rootY + 36} className={styles.rootSub}>{ROOT.sub}</text>
          </g>

          {/* ── Category nodes ── */}
          {catNodes.map((node, i) => (
            <g key={`cat-${i}`} className={styles.catNode}>
              <rect x={node.x} y={node.y} width={node.w} height={node.h} rx="3" className={styles.catRect} />
              <text x={node.x + node.w / 2} y={node.y + node.h / 2 + 4} className={styles.catLabel}>
                {node.label}
              </text>
            </g>
          ))}

          {/* ── Item nodes ── */}
          {itemNodes.map((node, i) => (
            <g key={`item-${i}`} className={styles.itemNode}>
              <rect x={node.x} y={node.y} width={node.w} height={node.h} rx="3" className={styles.itemRect} />
              <text x={node.x + node.w / 2} y={node.y + node.h / 2 + 4} className={styles.itemLabel}>
                {node.label}
              </text>
            </g>
          ))}
        </svg>
      </div>
    </div>
  )
}

// Elbow path: horizontal line from source, then vertical to target Y, then horizontal to target
function elbowPath({ x1, y1, x2, y2 }) {
  const midX = x1 + (x2 - x1) / 2
  return `M ${x1} ${y1} L ${midX} ${y1} L ${midX} ${y2} L ${x2} ${y2}`
}